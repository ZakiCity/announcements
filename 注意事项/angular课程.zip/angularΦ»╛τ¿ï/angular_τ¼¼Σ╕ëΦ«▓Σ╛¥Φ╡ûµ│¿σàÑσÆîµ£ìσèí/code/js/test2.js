/**
 * Created by qingyun on 16/11/7.
 */
console.log(a);